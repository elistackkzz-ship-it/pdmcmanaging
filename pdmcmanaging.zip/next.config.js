/** Next.js configuration for a simple export */
const nextConfig = {
  reactStrictMode: true,
}
module.exports = nextConfig